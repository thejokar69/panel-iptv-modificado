<?php


$panel_name = 'HC All in One';
$show_toa = 'yes';
$show_ip = 'yes';

?>